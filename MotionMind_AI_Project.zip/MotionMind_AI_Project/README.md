# MotionMind AI — Human Motion Prediction Using LSTM

## Project summary
MotionMind AI is an educational deep-learning prototype that predicts the next 2D human skeleton pose from a short sequence of previous poses. It uses an LSTM recurrent neural network and compares its performance against a simple persistence baseline.

## Dataset and data scope
This starter notebook creates procedural (synthetic) articulated skeleton sequences for four motion patterns: walking, waving, squatting and raising arms. No external dataset download is required. The generated data allows the full model pipeline to run quickly and reproducibly.

**Important:** Synthetic data is not equivalent to real human motion-capture data. Do not claim real-world accuracy. For a research extension, replace the synthetic sequence generator with a properly licensed motion-capture dataset or pose keypoints extracted from videos, and evaluate on subjects not seen during training.

## Run in Google Colab
1. Download and extract this ZIP.
2. Open `notebooks/MotionMind_AI_LSTM_Human_Motion_Prediction.ipynb` in Google Colab.
3. Select a GPU runtime if available (Runtime > Change runtime type > T4 GPU). CPU can also run this small prototype.
4. Run all cells from top to bottom.
5. Review training/validation loss, test MSE/MAE, baseline comparison and pose visualizations.
6. Save screenshots of your actual outputs for the project submission.

## Architecture
- Input: 20 time steps × 28 coordinate features (14 joints × x/y)
- LSTM layer with 128 units
- Dropout
- LSTM layer with 64 units
- Dense regression output for the next 2D pose
- Loss: Mean Squared Error
- Metrics: MAE and MSE

## Tech stack
Python, TensorFlow/Keras, LSTM, NumPy, Matplotlib, scikit-learn, Google Colab.

## Project structure
- `notebooks/MotionMind_AI_LSTM_Human_Motion_Prediction.ipynb` — executable notebook
- `src/README.md` — source-code extension notes
- `PROJECT_DESCRIPTION.txt` — project title, description and technology stack
- `requirements.txt` — dependencies

## Limitations
The included data is synthetic. The prototype demonstrates LSTM-based sequence prediction, not production-grade human motion forecasting. A real-world version needs a suitable real motion dataset, robust pose estimation, and external evaluation.

## Attribution
This starter project was assembled for educational use. If you incorporate external datasets, libraries, or code, cite their sources and comply with their licences.
