# Source extension notes

The complete executable implementation is in the notebook. The synthetic pose generator is included in the notebook to make the project reproducible without external data downloads.

For a real-world extension:
1. Obtain a licensed human motion-capture dataset or video collection.
2. Extract consistent 2D/3D pose keypoints with a pose-estimation model.
3. Normalize coordinates and align sequences to a common skeleton topology.
4. Train/validate/test with subject-independent splits to avoid identity leakage.
5. Evaluate short- and long-horizon prediction errors and compare with persistence/linear baselines.
